﻿public class Player : Character
{
}